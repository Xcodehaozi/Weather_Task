//
//  WDTableViewCell.h
//  Weather_demo
//
//  Created by 刘昊 on 2019/6/12.
//  Copyright © 2019 刘昊. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WDModel.h"

@interface WDTableViewCell : UITableViewCell

@property (nonatomic, strong) WDModel *model;

@end


