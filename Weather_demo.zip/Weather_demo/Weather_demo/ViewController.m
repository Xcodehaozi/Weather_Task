//
//  ViewController.m
//  Weather_demo
//
//  Created by 刘昊 on 2019/6/12.
//  Copyright © 2019 刘昊. All rights reserved.
//

/*
 *  Chicago   https://forecast.weather.gov/MapClick.php?&lat=41.88&lon=-87.63&FcstType=json
 *  New York  https://forecast.weather.gov/MapClick.php?&lat=42.94&lon=-75.61&FcstType=json
 *  Miami     https://forecast.weather.gov/MapClick.php?&lat=25.77&lon=-80.2&FcstType=json
 *  San Francisco https://forecast.weather.gov/MapClick.php?&lat=37.78&lon=-122.42&FcstType=json
 */


#import "ViewController.h"
#import "WDTableViewCell.h"
#import "WDModel.h"

#import <Masonry.h>
#import <AFNetworking.h>

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) WDModel *model;

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, strong) NSString *ChicagoTempUrl;

@property (nonatomic, strong) NSString *NewYorkTempUrl;

@property (nonatomic, strong) NSString *MiamiTempUrl;

@property (nonatomic, strong) NSString *SanTempUrl;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    self.tableView.backgroundColor = [UIColor cyanColor];
    self.dataArray = [NSMutableArray array];
}


- (void)viewWillAppear:(BOOL)animated{
    
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc] init];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/json", @"text/javascript", @"application/geo+json", nil];
    __weak typeof(self) weakSelf = self;
    
    // 创建串行队列
    dispatch_queue_t customQuue = dispatch_queue_create("com.wumeng.network", DISPATCH_QUEUE_SERIAL);
    // 创建信号量并初始化
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    
    // 添加任务
    dispatch_async(customQuue, ^{
        // Chicago
        [manager GET:@"https://api.weather.gov/points/41.88,-87.63" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            weakSelf.ChicagoTempUrl = result[@"properties"][@"forecast"];
            dispatch_semaphore_signal(sem);
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
        
        [manager GET:weakSelf.ChicagoTempUrl parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            WDModel *model = [[WDModel alloc] init];
            model.temperature = [weakSelf tempWithNumber:result[@"properties"][@"periods"][0][@"temperature"]];
            model.detail = result[@"properties"][@"periods"][0][@"detailedForecast"];
            model.name = @"Chicago";
            model.latitude = 41.88;
            model.longitude = -87.63;
            [weakSelf.dataArray addObject:model];
            dispatch_semaphore_signal(sem);

        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
        
        // New York
        [manager GET:@"https://api.weather.gov/points/40.78,-73.97" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            weakSelf.NewYorkTempUrl = result[@"properties"][@"forecast"];
            dispatch_semaphore_signal(sem);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
        
        [manager GET:weakSelf.NewYorkTempUrl parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            WDModel *model = [[WDModel alloc] init];
            model.temperature = [weakSelf tempWithNumber:result[@"properties"][@"periods"][0][@"temperature"]];
            model.detail = result[@"properties"][@"periods"][0][@"detailedForecast"];
            model.name = @"New York";
            model.latitude = 40.78;
            model.longitude = -73.97;
            [weakSelf.dataArray addObject:model];
            dispatch_semaphore_signal(sem);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
        
        // Miami
        [manager GET:@"https://api.weather.gov/points/25.77,-80.2" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            weakSelf.MiamiTempUrl = result[@"properties"][@"forecast"];
            dispatch_semaphore_signal(sem);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
        
        [manager GET:weakSelf.MiamiTempUrl parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            WDModel *model = [[WDModel alloc] init];
            model.temperature = [weakSelf tempWithNumber:result[@"properties"][@"periods"][0][@"temperature"]];
            model.detail = result[@"properties"][@"periods"][0][@"detailedForecast"];
            model.name = @"Miami";
            model.latitude = 25.77;
            model.longitude = -80.2;
            [weakSelf.dataArray addObject:model];
            dispatch_semaphore_signal(sem);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
        
        // San Francisco
        [manager GET:@"https://api.weather.gov/points/37.78,-122.42" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            weakSelf.SanTempUrl = result[@"properties"][@"forecast"];
            dispatch_semaphore_signal(sem);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
        
        [manager GET:weakSelf.SanTempUrl parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            WDModel *model = [[WDModel alloc] init];
            model.temperature = [weakSelf tempWithNumber:result[@"properties"][@"periods"][0][@"temperature"]];
            model.detail = result[@"properties"][@"periods"][0][@"detailedForecast"];
            model.name = @"San Francisco";
            model.latitude = 37.78;
            model.longitude = -122.42;
            [weakSelf.dataArray addObject:model];
            [weakSelf tableView];
            dispatch_semaphore_signal(sem);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            dispatch_semaphore_signal(sem);
        }];
        dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);
    });
}

- (NSString *)tempWithNumber:(NSNumber *)num{
    NSString *tempStr = [NSString stringWithFormat:@"%@",num];
    return tempStr;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 400.f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    WDTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"WDTableViewCell" forIndexPath:indexPath];
    cell.model = self.dataArray[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}


- (UITableView *)tableView{
    if (!_tableView) {
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        tableView.delegate = self;
        tableView.dataSource = self;
        [self.view addSubview:tableView];
        [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.bottom.mas_equalTo(0);
        }];
        [tableView registerClass:[WDTableViewCell class] forCellReuseIdentifier:@"WDTableViewCell"];
        _tableView = tableView;
    }
    return _tableView;
}

@end
