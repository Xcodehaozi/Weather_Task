//
//  WDTableViewCell.m
//  Weather_demo
//
//  Created by 刘昊 on 2019/6/12.
//  Copyright © 2019 刘昊. All rights reserved.
//

#import "WDTableViewCell.h"
#import <Masonry.h>
#import <AFNetworking.h>
#import <MapKit/MapKit.h>

@interface WDTableViewCell()<MKMapViewDelegate>

@property (nonatomic, strong) UILabel *nameLabel;

@property (nonatomic, strong) UILabel *tempLabel;

@property (nonatomic, strong) UILabel *detailLabel;

@property (nonatomic, strong) MKMapView *mapView;



@end

@implementation WDTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    return self;
}

- (void)setModel:(WDModel *)model{
    _model = model;
    
    self.nameLabel.text = model.name;
    self.tempLabel.text = [model.temperature stringByAppendingString:@"°F"];
    self.detailLabel.text = model.detail;
    self.mapView.backgroundColor = [UIColor cyanColor];
    CLLocation *location = [[CLLocation alloc] initWithLatitude:model.latitude longitude:model.longitude];
    self.mapView.centerCoordinate = location.coordinate;
    // 设置跨度 : 跨度变小,地图显示缩大  (地图的范围跨度 * 比例系数)
    MKCoordinateSpan span = MKCoordinateSpanMake(0.2, 0.2);
    //设置地图范围
    [self.mapView setRegion:MKCoordinateRegionMake(location.coordinate, span) animated:YES];
}


- (UILabel *)nameLabel{
    if (!_nameLabel) {
        UILabel *nameLabel = [[UILabel alloc] init];
        nameLabel.font = [UIFont systemFontOfSize:18];
        nameLabel.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:nameLabel];
        [nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(10);
            make.width.mas_offset(120);
            make.height.mas_offset(20);
            make.top.mas_offset(10);
        }];
        _nameLabel = nameLabel;
    }
    return _nameLabel;
}

- (UILabel *)tempLabel{
    if (!_tempLabel) {
        UILabel *tempLabel = [[UILabel alloc] init];
        tempLabel.font = [UIFont boldSystemFontOfSize:18];
        tempLabel.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:tempLabel];
        [tempLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.nameLabel.mas_right);
            make.width.mas_offset(50);
            make.height.mas_offset(20);
            make.top.mas_offset(10);
        }];
        _tempLabel = tempLabel;
    }
    return _tempLabel;
}

- (UILabel *)detailLabel{
    if (!_detailLabel) {
        UILabel *detailLabel = [[UILabel alloc] init];
        detailLabel.font = [UIFont systemFontOfSize:14];
        detailLabel.textAlignment = NSTextAlignmentLeft;
        detailLabel.numberOfLines = 0;
        [self.contentView addSubview:detailLabel];
        [detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(10);
            make.right.mas_offset(10);
            make.height.mas_offset(100);
            make.top.mas_equalTo(self.nameLabel.mas_bottom);
        }];
        _detailLabel = detailLabel;
    }
    return _detailLabel;
}

- (MKMapView *)mapView{
    if (!_mapView) {
        MKMapView *mapView = [[MKMapView alloc] init];
        mapView.zoomEnabled = NO;
        mapView.scrollEnabled = NO;
        mapView.rotateEnabled = NO;
        mapView.delegate = self;
        [self.contentView addSubview:mapView];
        [mapView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(10);
            make.right.mas_offset(10);
            make.bottom.mas_offset(0);
            make.top.mas_equalTo(self.detailLabel.mas_bottom);
        }];
        _mapView = mapView;
    }
    return _mapView;
}

@end
