//
//  WDModel.h
//  Weather_demo
//
//  Created by 刘昊 on 2019/6/12.
//  Copyright © 2019 刘昊. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WDModel : NSObject

/**
 *  name
 */
@property (nonatomic, copy) NSString *name;

/**
 *  temperature
 */
@property (nonatomic, copy) NSString *temperature;

/**
 *  detail
 */
@property (nonatomic, copy) NSString *detail;

/**
 *  icon
 */
@property (nonatomic, copy) NSString *icon;

/**
 *  latitude
 */
@property (nonatomic, assign) double latitude;

/**
 *  longitude
 */
@property (nonatomic, assign) double longitude;

@end
